# Kit du projet Claude · Budget formation

Ce kit contient tout ce qu’il faut pour créer le projet Claude de votre groupe, ou le recréer sur un autre compte si la limite de l’offre gratuite est atteinte.

## Ce qu’il contient

– 01-INSTRUCTIONS-DU-PROJET.md : à coller dans « Définir les instructions du projet » (« Set project instructions ») ;
– 02-consignes : les six consignes des conversations, dans l’ordre du parcours ;
– 03-fichiers-du-projet : MODELE-DE-DONNEES.md (exemple) et ETAT-DU-PROJET.md, à ajouter aux fichiers du projet.

## Comment s’en servir

1. Dans Claude, volet de gauche : « Projets » (« Projects »), puis créez un projet au nom de votre application.
2. Ouvrez 01-INSTRUCTIONS-DU-PROJET.md. Remplacez [collez votre cahier des charges] par votre cahier des charges (activités 2.1, 2.3 et 3.3 du parcours), et {notre adresse Gmail} par l’adresse du groupe. Collez le tout dans les instructions du projet, puis enregistrez.
3. Ajoutez les fichiers de 03-fichiers-du-projet au projet : « + », puis téléversez le fichier.
4. Pour chaque étape, ouvrez une nouvelle conversation dans le projet, renommez-la avec le titre de la consigne, puis collez la consigne.
5. À la fin de chaque conversation, remplacez ETAT-DU-PROJET.md dans le projet par la version que Claude vous donne.

Astuce : dans le parcours, le bouton « Copier » des activités 4.1, 5.2, 5.3 et 6.3 remplace déjà les crochets par vos réponses saisies.

Le modèle de données fourni est un exemple : si votre groupe a construit le sien à la conversation 01, gardez le vôtre.
