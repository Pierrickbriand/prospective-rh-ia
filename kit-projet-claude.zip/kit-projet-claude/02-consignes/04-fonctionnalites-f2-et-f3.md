# Conversation 04 · Fonctionnalités F2 et F3

Ouvrez une nouvelle conversation dans le projet, renommez-la « 04 · Fonctionnalités F2 et F3 », puis collez la consigne ci-dessous.

Ajoute nos fonctionnalités F2 et F3 :
[collez vos fonctionnalités F2 et F3]
Rappel de nos règles : l’application propose, une personne décide. Un changement de statut (validée, refusée) se fait toujours par un bouton qu’une personne clique, et il s’inscrit dans un journal (date, statut avant, statut après).
Livre les fichiers complets et, pour chaque fonctionnalité, un test chiffré à refaire dans le classeur.
Termine par ETAT-DU-PROJET.md.
