# Conversation 06 · Rappels, transparence et publication

Ouvrez une nouvelle conversation dans le projet, renommez-la « 06 · Rappels, transparence et publication », puis collez la consigne ci-dessous.

1. Ajoute un courriel de rappel : chaque lundi à 8 h, le manager reçoit la liste des demandes qui attendent son avis depuis plus de 7 jours. Les adresses sont les alias de notre Gmail. Crée une fonction envoyerRappels, que nous lançons à la main pour tester, puis une fonction installerDeclencheur, que nous lancerons une fois (Google l’exécute entre 8 h et 9 h).
2. Ajoute une page « À propos » : la finalité de l’application, les données utilisées, leur durée de conservation, qui décide et sur quels critères, à qui s’adresser. Nous te donnons nos décisions :
[collez vos décisions RH]
3. Guide-nous pour publier : « Déployer », « Nouveau déploiement », « Application Web », « Exécuter en tant que : Moi », « Qui a accès : Moi uniquement ».
Livre les fichiers complets et trois tests : un cas normal, un cas limite, une erreur de saisie.
Termine par ETAT-DU-PROJET.md.
