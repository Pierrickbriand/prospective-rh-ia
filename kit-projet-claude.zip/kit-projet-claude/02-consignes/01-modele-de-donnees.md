# Conversation 01 · Modèle de données

Ouvrez une nouvelle conversation dans le projet, renommez-la « 01 · Modèle de données », puis collez la consigne ci-dessous.

Lis notre cahier des charges dans les instructions du projet.
1. Pose-nous au plus trois questions, une à la fois.
2. Propose le modèle de données : les onglets du classeur (par exemple Paramètres, Salariés, Catalogue, Demandes) et, pour chaque onglet, les colonnes, leur rôle et leur format. Signale les colonnes calculées.
3. Après notre validation, produis la fiche MODELE-DE-DONNEES.md, puis un jeu de données fictif et cohérent : 20 salariés (code, service, poste, temps de travail, date de la dernière formation, sans nom ni salaire ni âge), un manager par service (code, adresse alias), 8 formations (intitulé, organisme fictif, durée en heures, coût pédagogique), 15 demandes de formation aux statuts variés (à valider, validée, refusée, réalisée), un onglet Journal vide (date, demande, statut avant, statut après) et, dans Paramètres, l’année, le budget annuel alloué, notre adresse Gmail et les seuils d’alerte (10 % du budget, 7 jours).
4. Livre chaque onglet en CSV séparé par des points-virgules, dans un bloc distinct : dates au format AAAA-MM-JJ, montants sans espace ni symbole €.
5. Explique-nous, pas à pas, comment créer le classeur et remplir chaque onglet : coller le bloc en A1, puis « Données », « Scinder le texte en colonnes », séparateur point-virgule.
Termine par ETAT-DU-PROJET.md.
