# Conversation 05 · Tableau de bord

Ouvrez une nouvelle conversation dans le projet, renommez-la « 05 · Tableau de bord », puis collez la consigne ci-dessous.

Ajoute un écran Tableau de bord :
– budget alloué, engagé, consommé, disponible, et taux de réalisation du budget ;
– taux d’accès à la formation (salariés formés ÷ effectif) et heures de formation par salarié ;
– demandes par statut et par service ; taux d’accès des salariés à temps partiel et à temps plein ;
– des alertes avec des seuils lus dans l’onglet Paramètres (par exemple : disponible sous 10 % de l’alloué, demande à valider depuis plus de 7 jours).
Livre les fichiers complets. Pour chaque indicateur, donne la formule à écrire dans le classeur pour le vérifier à la main.
Termine par ETAT-DU-PROJET.md.
