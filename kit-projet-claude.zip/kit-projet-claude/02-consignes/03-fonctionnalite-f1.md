# Conversation 03 · Fonctionnalité F1

Ouvrez une nouvelle conversation dans le projet, renommez-la « 03 · Fonctionnalité F1 », puis collez la consigne ci-dessous.

Ajoute notre fonctionnalité F1 :
[collez votre fonctionnalité F1]
Elle lit et écrit dans le classeur, par nom de colonne. Si elle ajoute une ligne, elle remplit toutes les colonnes et ne touche à aucune colonne calculée.
Ajoute un contrôle des saisies : champ vide, coût négatif, date impossible. Le message d’erreur s’affiche en clair dans la page.
Livre les fichiers complets et un test : ce que nous saisissons, et ce que nous devons voir ensuite dans le classeur.
Termine par ETAT-DU-PROJET.md.
