# Conversation 02 · Premier écran

Ouvrez une nouvelle conversation dans le projet, renommez-la « 02 · Premier écran », puis collez la consigne ci-dessous.

Nous avons ouvert le projet Apps Script lié à notre classeur (« Extensions », « Apps Script »).
Écris la première version de l’application web :
– Code.gs : doGet et une fonction qui lit le budget et les demandes dans le classeur ;
– Index.html : l’accueil, avec le nom de l’application, le budget alloué, engagé, consommé et disponible, et le nombre de demandes à valider.
Les chiffres sont lus dans le classeur, jamais écrits dans le code. Livre les fichiers complets, puis les étapes : coller, enregistrer, lancer une fonction pour accepter les autorisations Google, « Déployer », « Tester les déploiements ».
Donne-nous le calcul à refaire à la main dans le classeur pour vérifier chaque chiffre de l’accueil.
Termine par ETAT-DU-PROJET.md.
