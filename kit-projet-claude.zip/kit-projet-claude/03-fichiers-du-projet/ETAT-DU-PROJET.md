# État du projet · Budget formation

## Versions

– aucune version pour l’instant.

## Décisions

– données entièrement fictives ;
– l’application propose, une personne décide.

## Points ouverts

– modèle de données et classeur (conversation 01).
