# Kit de secours · Budget formation

Ce kit sert de porte de sortie. Utilisez-le si votre groupe bloque à la conversation 01 (modèle de données) ou 02 (premier écran), ou si la limite de l’offre gratuite de Claude est atteinte. Toutes les données sont fictives.

## Ce qu’il contient

– 01-classeur-budget-formation.xlsx : six onglets prêts à l’emploi (Paramètres, Managers, Salariés, Catalogue, Demandes, Journal) ;
– 02-MODELE-DE-DONNEES.md : la description de chaque onglet et de chaque colonne ;
– 03-ETAT-DU-PROJET.md : l’état du projet, à mettre à jour à la fin de chaque conversation ;
– 04-code-de-depart : Code.gs et Index.html, l’accueil de l’application (budget alloué, engagé, consommé, disponible).

## Le classeur (remplace la conversation 01)

1. Dans Google Drive : « Nouveau », « Importer un fichier », puis choisissez 01-classeur-budget-formation.xlsx.
2. Ouvrez-le, puis « Fichier », « Enregistrer au format Google Sheets ». Travaillez désormais dans cette copie.
3. Onglet Paramètres : remplacez le nom de l’entreprise (B2) et l’adresse Gmail (B5). Les adresses alias des managers et des salariés se calculent seules.
4. Partagez le classeur en modification avec les membres du groupe.
5. Dans le projet Claude : ajoutez 02-MODELE-DE-DONNEES.md et 03-ETAT-DU-PROJET.md aux fichiers du projet.

Vous pouvez renommer les services, les postes et les formations : gardez les noms des onglets et des colonnes, ou mettez MODELE-DE-DONNEES.md à jour.

## Le code de départ (remplace la conversation 02)

1. Dans le classeur : « Extensions », « Apps Script ». Renommez le projet du nom de votre application.
2. Ouvrez Code.gs, sélectionnez tout, collez le contenu de 04-code-de-depart/Code.gs, puis enregistrez.
3. « + », « HTML », tapez seulement Index, puis collez le contenu de Index.html et enregistrez.
4. Choisissez la fonction donneesAccueil dans la barre du haut, puis « Exécuter ». Acceptez les autorisations Google.
5. « Déployer », « Tester les déploiements », puis ouvrez le lien de l’application Web.

## Vérifier

L’accueil doit afficher : alloué 60 000 €, engagé 18 400 €, consommé 27 300 €, disponible 14 300 €, taux de réalisation 45,5 %, 2 demandes à valider. Refaites le calcul à la main dans le classeur.

## Reprendre avec Claude

Dans une nouvelle conversation du projet, écrivez : « Nous utilisons le kit de secours : le classeur suit MODELE-DE-DONNEES.md, et le code de départ affiche l’accueil. Lis ETAT-DU-PROJET.md, puis passons à notre fonctionnalité F1. » Puis collez la consigne de la conversation 03 du parcours.
