/**
 * Budget formation : code de départ du kit de secours (cours « Prospectives RH et IA »).
 * Script lié au classeur : ouvrez-le depuis le classeur, « Extensions », « Apps Script ».
 * Il lit le budget et les demandes, puis affiche l'accueil. Les chiffres viennent du classeur, jamais du code.
 * Données entièrement fictives.
 */

// Noms exacts des onglets du classeur (voir MODELE-DE-DONNEES.md)
const ONGLETS = {
  parametres: 'Paramètres',
  managers: 'Managers',
  salaries: 'Salariés',
  catalogue: 'Catalogue',
  demandes: 'Demandes',
  journal: 'Journal'
};

// Affiche la page de l'application
function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Budget formation')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// Lit un onglet : une ligne = un objet, rangé par nom de colonne
function lireOnglet_(nom) {
  const feuille = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nom);
  if (!feuille) {
    throw new Error('Onglet introuvable : ' + nom + '. Vérifiez son nom exact dans le classeur.');
  }
  const valeurs = feuille.getDataRange().getValues();
  const entetes = valeurs.shift().map(function (c) { return String(c).trim(); });
  return valeurs
    .filter(function (ligne) { return ligne.join('') !== ''; })
    .map(function (ligne) {
      const objet = {};
      entetes.forEach(function (entete, i) { objet[entete] = ligne[i]; });
      return objet;
    });
}

// Lit l'onglet Paramètres : colonne A, le réglage ; colonne B, sa valeur
function lireParametres_() {
  const feuille = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ONGLETS.parametres);
  if (!feuille) {
    throw new Error('Onglet introuvable : ' + ONGLETS.parametres + '.');
  }
  const parametres = {};
  feuille.getDataRange().getValues().slice(1).forEach(function (ligne) {
    if (String(ligne[0]).trim() !== '') {
      parametres[String(ligne[0]).trim()] = ligne[1];
    }
  });
  return parametres;
}

// Somme des coûts des demandes d'un statut donné
function sommeParStatut_(demandes, statut) {
  return demandes
    .filter(function (d) { return String(d['Statut']).trim() === statut; })
    .reduce(function (total, d) { return total + Number(d['Coût (€)'] || 0); }, 0);
}

// Données de l'accueil, appelées par la page avec google.script.run
// Lancez-la une fois depuis l'éditeur pour accepter les autorisations Google.
function donneesAccueil() {
  const p = lireParametres_();
  const demandes = lireOnglet_(ONGLETS.demandes);
  const alloue = Number(p['Budget alloué (€)'] || 0);
  const engage = sommeParStatut_(demandes, 'validée');
  const consomme = sommeParStatut_(demandes, 'réalisée');
  const disponible = alloue - engage - consomme;
  const seuil = Number(p['Seuil d’alerte du disponible (%)'] || 0);
  const resultat = {
    entreprise: String(p['Entreprise'] || ''),
    annee: String(p['Année'] || ''),
    alloue: alloue,
    engage: engage,
    consomme: consomme,
    disponible: disponible,
    tauxRealisation: alloue ? Math.round(consomme / alloue * 1000) / 10 : 0,
    aValider: demandes.filter(function (d) { return String(d['Statut']).trim() === 'à valider'; }).length,
    alerte: alloue > 0 && disponible < alloue * seuil / 100,
    seuil: seuil
  };
  Logger.log(JSON.stringify(resultat));
  return resultat;
}
