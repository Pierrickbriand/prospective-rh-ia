# Modèle de données · Budget formation

Classeur Google Sheets, base de données de l’application. Une ligne par enregistrement, une colonne par information, noms de colonnes fixes. Les colonnes calculées (fond gris) ne s’écrivent jamais depuis le code. Données entièrement fictives : aucun nom, aucun salaire, aucune évaluation.

## Paramètres

Colonne A, le réglage ; colonne B, sa valeur. Le code les lit par le texte de la colonne A.

– Entreprise : nom de l’entreprise du groupe ;
– Année : année budgétaire ;
– Budget alloué (€) : enveloppe de l’année ;
– Adresse Gmail : adresse du groupe, base des alias ;
– Seuil d’alerte du disponible (%) : alerte quand le disponible passe sous ce pourcentage de l’alloué ;
– Délai de relance (jours) : relance du manager au-delà de ce délai.

## Managers

– Code : M01, M02… ;
– Service : service dont le manager est responsable ;
– Adresse : calculée, alias de l’adresse Gmail (+m01).

## Salariés

– Code : S001, S002… ;
– Service ;
– Poste ;
– Temps de travail : Temps plein ou Temps partiel ;
– Date de la dernière formation : date (AAAA-MM-JJ) ;
– Manager : code du manager ;
– Adresse : calculée, alias de l’adresse Gmail (+s001).

## Catalogue

– Code : F01, F02… ;
– Intitulé ;
– Organisme : organisme fictif ;
– Durée (h) ;
– Coût pédagogique (€) ;
– Frais annexes (€) ;
– Coût total (€) : calculé, coût pédagogique + frais annexes.

## Demandes

– ID : D01, D02… ;
– Code salarié ;
– Code formation ;
– Coût (€) : coût total de la formation au moment de la demande ;
– Date de la demande : date (AAAA-MM-JJ) ;
– Statut : à valider, validée, refusée ou réalisée ;
– Date de la décision : vide tant que la demande est à valider ;
– Décidé par : code du manager ou « RH » ; une personne décide toujours ;
– Motif : obligatoire pour un refus.

## Journal

Une ligne à chaque changement de statut, écrite par l’application.

– Date ;
– Demande : ID de la demande ;
– Statut avant ;
– Statut après ;
– Par : code de la personne qui a cliqué.

## Règles de calcul

– engagé = somme des coûts des demandes validées ;
– consommé = somme des coûts des demandes réalisées ;
– disponible = alloué − engagé − consommé ;
– taux de réalisation du budget = consommé ÷ alloué.
