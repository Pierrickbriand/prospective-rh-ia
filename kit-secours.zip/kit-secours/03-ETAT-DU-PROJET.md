# État du projet · Budget formation

## Versions

– version 1 : classeur du kit de secours importé ; code de départ (accueil : alloué, engagé, consommé, disponible, demandes à valider).

## Décisions

– données entièrement fictives ;
– l’application propose, une personne décide.

## Points ouverts

– fonctionnalités F1 à F3 à construire (conversations 03 et 04).
